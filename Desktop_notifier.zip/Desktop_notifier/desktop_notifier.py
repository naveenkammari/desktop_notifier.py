import psutil
def getListOfProcessSortedByMemory():
    '''
    Get list of running process sorted by Memory Usage
    '''
    listOfProcObjects = []
    # Iterate over the list
    for proc in psutil.process_iter():
       try:
           # Fetch process details as dict
           pinfo = proc.as_dict(attrs=['pid', 'name', 'username'])
           pinfo['vms'] = proc.memory_info().vms / (1024 * 1024)
           # Append dict to list
           listOfProcObjects.append(pinfo);
       except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
           pass
    # Sort list of dict by key vms i.e. memory usage
    listOfProcObjects = sorted(listOfProcObjects, key=lambda procObj: procObj['vms'], reverse=True)
    return listOfProcObjects


#psutil.virtual_memory().percent


threshold=0
import tkinter as tk
def qui():
    my_label1.config(text = "Current Ram Utilization: "+str(psutil.virtual_memory().percent))

def show_entry_fields():
    global threshold
    threshold=int(e1.get())
    global master
    master.destroy()


master = tk.Tk()
master.geometry("400x400")
master.configure(bg='pink')


my_label=tk.Label(master,
         text="Enter Threshold value in %")
my_label.grid(row=4,padx=10, pady=30)
my_label1=tk.Label(master,
         text="Current Ram Utilization")
my_label1.grid(row=5)


e1 = tk.Entry(master)


e1.grid(row=4, column=1)

tk.Button(master,
          text='show',
          command=qui).grid(row=5,
                                    column=1,
                                    sticky=tk.W,
                                    pady=20,padx=10)
tk.Button(master,
          text='SET THE ALARM', command=show_entry_fields).grid(row=7,
                                                       column=1,
                                           
                                                       sticky=tk.W,
                                                       pady=20,padx=10)

tk.mainloop()


from plyer.utils import platform
from plyer import notification



not_times=0
import time
while True:
    if(psutil.virtual_memory().percent>threshold):
        fresh=1
        ss=""
        listOfRunningProcess = getListOfProcessSortedByMemory()
        for elem in listOfRunningProcess[:5] :
            print(elem)
            ss=ss+str(elem['name'])+" - "+str(elem['vms'])+"\n"
        if(not_times<5):
            notification.notify(
                title=str(threshold)+"% threshold   Current  - "+ str(psutil.virtual_memory().percent)+"%\n",
                message=ss,
                app_name='Here is the application name\nhjgsgs',
                app_icon='computer.ico',
            )
            not_times=not_times+1
        time.sleep(10)
           

    else:
        not_times=0
           
   